Shanty Shootah'
A game made in 72 hours during the Itch.io Mini Jam 108: Seaside

Written in Python using Pygame

The worst code you've ever seen & soundtrack by Kamil "kate." Wardęga

Beautiful pixel art by Emma Arthur
